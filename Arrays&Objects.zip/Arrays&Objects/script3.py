class Inventory:
    store_name = "Carlo's Bookstore"
    store_address = "14 Washington St, Hoboken, NJ 07030"
    stock = [
        {
            "title": "The Cat in the Hat",
            "author": "Dr. Suess",
            "price": 19.99
        },
        {
            "title": "To Kill a Mockingbird",
            "author": "Harper Lee",
            "price": 15.99
        },
        {
            "title": "Don Quixote",
            "author": "Miguel de Cervantes",
            "price": 10.50
        },
        {
            "title": "The Lord of the Rings",
            "author": "J.R.R. Tolkien",
            "price": 5.90
        },
        {
            "title": "Hamlet",
            "author": "William Shakespeare",
            "price": 7.20
        }
    ]
